package com.amaralzaao.SwiftAndSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwiftAndSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
