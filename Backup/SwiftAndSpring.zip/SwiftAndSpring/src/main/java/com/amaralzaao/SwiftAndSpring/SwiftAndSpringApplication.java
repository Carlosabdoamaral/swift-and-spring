package com.amaralzaao.SwiftAndSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwiftAndSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwiftAndSpringApplication.class, args);
	}

}
